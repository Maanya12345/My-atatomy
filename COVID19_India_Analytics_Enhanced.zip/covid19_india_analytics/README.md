# COVID-19 India Insight Studio — Enhanced Mini Project

A reproducible exploratory data analysis (EDA) project based on the supplied `MiniProject_COVID19_India_EDA.ipynb`, upgraded with a multi-tab Streamlit dashboard, validation pipeline, state comparisons, daily trend smoothing, data-quality audit, exports, and an HTML report generator.

## Important data integrity note
The configured public repositories may contain historical data and may stop updating. A refresh fetches the latest file available at the source; it does **not** mean live surveillance. The app has an optional **synthetic demo mode** to test the interface when internet access or the public repository is unavailable. Demo data is generated for demonstration only and must never be reported as real COVID-19 observations.

## Features
- Dashboard KPI cards, cumulative trends, state/UT comparisons, recovery/death rates, estimated active cases, and reported daily case trends.
- Adjustable date range, state selection, ranking metric, and moving-average smoothing.
- Source CSV upload supporting both canonical columns (`date,state,confirmed,deaths,cured`) and the original notebook's column names.
- Cleaning and quality audit: date parsing, numeric coercion, duplicate date/state consolidation, missing-value summary, derived indicators, and zero-denominator protection.
- Optional vaccination chart from Our World in Data when its source is accessible.
- Download filtered, cleaned, state ranking, national daily summary, and vaccination CSV files.
- Generate a portable HTML report from current filters; the report can be printed to PDF from a browser.
- Unit tests and the original notebook retained.

## Run on Windows
Install Python 3.10+ first. Extract the ZIP, open a terminal in the project folder, then run:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Alternatively, double-click `run_windows.bat` (it installs dependencies and starts Streamlit).

## Run on macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

## Run tests

```bash
python -m pytest -q
```

## Data sources
- Historical India state/UT data: https://github.com/imdevskp/covid-19-india-data
- India vaccination data: https://github.com/owid/covid-19-data/tree/master/public/data/vaccinations/country_data

Source availability and reporting definitions can change. Record the retrieval date and observation window in any academic report.

## CSV schema
Required: `date,state,confirmed,deaths,cured`
Optional: `new_cases,new_deaths,new_recovered,lat,long`
Original aliases accepted include `Date`, `Name of State / UT`, `Total Confirmed cases`, `Death`, `Cured/Discharged/Migrated`, and `New cases`.

## Methodology
1. Ingest a public CSV or user-provided CSV.
2. Validate required fields and normalize dates/numeric columns.
3. Remove invalid date/state records and consolidate duplicate date/state pairs.
4. Derive recovery rate, reported death rate, estimated active cases, and missing daily series where feasible.
5. Explore trends and state-level snapshots; export filtered records or an HTML report.

## Limitations to discuss in your viva
- Historical reporting revisions, backfills, inconsistent state names, and changing reporting practices can affect comparisons.
- Active cases are estimated as confirmed − recovered − deaths, clipped at zero; it is not a clinical status count.
- Daily case counts may be inferred from cumulative differences when a daily field is absent.
- The app is descriptive; it does not establish causation or provide medical advice.
- A synthetic demo dataset is not real data. Replace it with a verifiable source before making findings.

## Viva-ready explanation
**Problem:** raw epidemic data is difficult to compare across dates and states.
**Solution:** a reproducible pipeline that validates and normalizes records, derives transparent indicators, visualizes trends, and exports results.
**Validation:** required-column checks, invalid-date handling, duplicate consolidation, zero-denominator handling, and unit tests.
**Novelty of implementation:** combines exploratory analysis with data provenance warnings, an explicit synthetic demo fallback, a quality audit, interactive filters, and a report export. Do not claim the underlying epidemiological method itself is novel.
