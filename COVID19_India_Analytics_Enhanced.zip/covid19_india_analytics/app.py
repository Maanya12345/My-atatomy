"""COVID-19 India Insight Studio: reproducible historical EDA dashboard."""
from __future__ import annotations
from datetime import timedelta
from io import BytesIO
import html
import requests
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from data_utils import normalise_cases, add_derived, quality_summary

st.set_page_config(page_title="COVID-19 India | Insight Studio", page_icon="🧬", layout="wide", initial_sidebar_state="expanded")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root{--ink:#14233b;--muted:#64748b;--line:#dce5ef;--blue:#2563eb;--teal:#0d9488}
.stApp{background:linear-gradient(180deg,#f7faff 0%,#eef4fa 100%);font-family:'DM Sans',sans-serif}
h1,h2,h3{font-family:'Space Grotesk',sans-serif;color:var(--ink)}
.block-container{padding-top:1.5rem;max-width:1500px}
[data-testid="stMetric"]{background:rgba(255,255,255,.94);border:1px solid var(--line);border-radius:16px;padding:16px 18px;box-shadow:0 6px 22px rgba(15,23,42,.04)}
[data-testid="stMetricLabel"]{color:#53657c;font-weight:600}
.hero{background:linear-gradient(120deg,#10233f,#164e79 72%,#0f766e);border-radius:22px;padding:28px 30px;color:white;margin-bottom:20px}
.hero h1{color:white;margin:0;font-size:2.1rem}.hero p{color:#d8e8f5;margin:.45rem 0 0}
.notice{background:#fff8e8;border:1px solid #f3d79c;border-left:5px solid #e5a11a;border-radius:10px;padding:13px 16px;color:#684b12}
.small-muted{color:#64748b;font-size:.86rem}
section[data-testid="stSidebar"]{background:#f2f6fb;border-right:1px solid #dce5ef}
</style>""", unsafe_allow_html=True)

CASES_URL="https://raw.githubusercontent.com/imdevskp/covid-19-india-data/master/complete.csv"
VAX_URL="https://raw.githubusercontent.com/owid/covid-19-data/master/public/data/vaccinations/country_data/India.csv"
TIMEOUT=25

@st.cache_data(ttl=900, show_spinner=False)
def fetch_csv(url: str) -> pd.DataFrame:
    r=requests.get(url,timeout=TIMEOUT,headers={"User-Agent":"COVID19-India-Insight-Studio/2.0"})
    r.raise_for_status()
    return pd.read_csv(BytesIO(r.content))

def demo_data() -> pd.DataFrame:
    """Clearly synthetic demo data to keep the app demonstrable without network access."""
    rng=np.random.default_rng(42)
    dates=pd.date_range("2020-03-01",periods=150,freq="D")
    states={"Maharashtra":1.0,"Tamil Nadu":.58,"Delhi":.46,"Gujarat":.38,"Uttar Pradesh":.35,"West Bengal":.28,"Karnataka":.25,"Rajasthan":.22}
    rows=[]
    for state,scale in states.items():
        daily=np.maximum(0,(np.exp(np.linspace(0,4.6,len(dates)))/(1+np.exp(np.linspace(0,4.6,len(dates))-3.8)))*scale*80 + rng.normal(0,scale*12,len(dates))).astype(int)
        confirmed=np.cumsum(daily)
        cured=(confirmed*np.clip(np.linspace(.02,.78,len(dates))+rng.normal(0,.008,len(dates)),0,1)).astype(int)
        deaths=(confirmed*np.clip(np.linspace(.005,.025,len(dates))+rng.normal(0,.001,len(dates)),0,1)).astype(int)
        for i,dt in enumerate(dates):
            rows.append({"date":dt,"state":state,"confirmed":int(confirmed[i]),"deaths":int(deaths[i]),"cured":int(cured[i]),"new_cases":int(daily[i])})
    return pd.DataFrame(rows)

def format_num(x):
    try: return f"{int(round(float(x))):,}"
    except (ValueError,TypeError): return "—"

def make_report(filtered: pd.DataFrame, source_mode: str, metric: str) -> bytes:
    latest_date=filtered.date.max()
    snap=filtered[filtered.date.eq(latest_date)].groupby("state",as_index=False)[["confirmed","cured","deaths","active_estimate"]].max().sort_values("confirmed",ascending=False)
    top=snap.head(10)
    national=filtered.groupby("date",as_index=False)[["confirmed","cured","deaths","new_cases","active_estimate"]].sum()
    peak=national.loc[national.new_cases.idxmax()] if len(national) else None
    rows="".join(f"<tr><td>{html.escape(str(r.state))}</td><td>{format_num(r.confirmed)}</td><td>{format_num(r.cured)}</td><td>{format_num(r.deaths)}</td><td>{format_num(r.active_estimate)}</td></tr>" for r in top.itertuples())
    peak_line=f"Peak reported daily cases in filtered window: {format_num(peak.new_cases)} on {pd.Timestamp(peak.date):%d %b %Y}." if peak is not None else ""
    body=f'''<!doctype html><html><head><meta charset="utf-8"><title>COVID-19 India EDA Report</title><style>body{{font:16px Arial,sans-serif;max-width:1000px;margin:40px auto;color:#172b4d;line-height:1.55}}h1{{color:#174b75}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #d7e0ea;padding:9px;text-align:left}}th{{background:#eaf2f8}}.note{{background:#fff4d6;padding:14px;border-left:4px solid #d99a00}}</style></head><body><h1>COVID-19 India — Exploratory Data Analysis</h1><p><b>Generated:</b> {pd.Timestamp.now():%d %b %Y, %H:%M} &nbsp; <b>Data mode:</b> {html.escape(source_mode)}</p><p><b>Observation window:</b> {filtered.date.min():%d %b %Y} – {latest_date:%d %b %Y}</p><h2>Summary</h2><ul><li>Rows in filtered dataset: {len(filtered):,}</li><li>States/UT labels: {filtered.state.nunique()}</li><li>Confirmed cumulative totals at latest date (selected states): {format_num(snap.confirmed.sum())}</li><li>Recovered cumulative totals: {format_num(snap.cured.sum())}</li><li>Reported deaths: {format_num(snap.deaths.sum())}</li><li>{html.escape(peak_line)}</li></ul><h2>State snapshot</h2><table><thead><tr><th>State / UT</th><th>Confirmed</th><th>Recovered</th><th>Deaths</th><th>Estimated active</th></tr></thead><tbody>{rows}</tbody></table><h2>Methodology</h2><p>Column names and data types are normalized; invalid dates are excluded; duplicate date/state rows are consolidated; derived indicators are calculated from cumulative values. Estimated active cases = confirmed − recovered − deaths, clipped at zero.</p><div class="note"><b>Interpretation warning:</b> Public COVID-19 repositories may be historical or frozen. Refreshing a source is not the same as receiving live surveillance data. This report is for educational analysis and is not medical advice. Check the underlying source and reporting definitions before using figures.</div><h2>Limitations</h2><p>Reporting practices and revisions vary. Cumulative state totals should not be added across different dates. Association between rates does not establish causation. Any demo dataset must be replaced by verified observations before academic submission.</p></body></html>'''
    return body.encode('utf-8')

st.markdown('<div class="hero"><h1>🧬 COVID-19 INDIA · INSIGHT STUDIO</h1><p>Historical epidemiology • State-level comparisons • Data quality • Transparent analysis</p></div>',unsafe_allow_html=True)
st.markdown('<div class="notice"><b>Data integrity note:</b> This dashboard is designed for historical exploratory analysis, not live case surveillance. The public repositories may be frozen. If the network source is unavailable, the app offers a clearly labelled <b>synthetic demo dataset</b> so you can test the interface; never present demo values as real observations.</div>',unsafe_allow_html=True)

with st.sidebar:
    st.header("⚙️ Data workspace")
    upload=st.file_uploader("Upload your own cases CSV",type=["csv"],help="Required columns: date, state, confirmed, deaths, cured. Original notebook column names are also supported.")
    use_demo=st.toggle("Use synthetic demo dataset",value=False,help="Illustrative values only; not real COVID-19 data.")
    refresh=st.button("↻ Refresh public source",use_container_width=True)
    st.divider()
    st.markdown("**Data sources**")
    st.markdown(f"[Historical state data ↗]({CASES_URL})")
    st.markdown(f"[OWID vaccination data ↗]({VAX_URL})")
    st.caption("Refresh cache: 15 minutes")
if refresh: fetch_csv.clear(); st.toast("Cached source cleared; trying to reload.")
source_mode="Public historical repository"; raw=None; source_error=None
if upload is not None:
    try: raw=pd.read_csv(upload); source_mode=f"Uploaded CSV · {upload.name}"
    except Exception as e: source_error=f"Unable to read upload: {e}"
elif use_demo:
    raw=demo_data(); source_mode="SYNTHETIC DEMO DATA — NOT REAL OBSERVATIONS"
else:
    try:
        with st.spinner("Fetching historical source…"): raw=fetch_csv(CASES_URL)
    except Exception as e:
        source_error=f"Public source unavailable ({type(e).__name__}: {e}). Upload a CSV or switch on synthetic demo mode."
        st.warning(source_error)
        if st.button("Load synthetic demo so I can explore the dashboard"):
            st.session_state["load_demo_once"]=True
        if st.session_state.get("load_demo_once"):
            raw=demo_data(); source_mode="SYNTHETIC DEMO DATA — NOT REAL OBSERVATIONS"
if raw is None:
    st.info("Choose a CSV upload or enable synthetic demo mode in the sidebar to explore all features.")
    st.stop()
try: cases=add_derived(normalise_cases(raw))
except Exception as e: st.error(f"Data validation failed: {e}"); st.stop()
if cases.empty: st.error("No valid observations remain after cleaning."); st.stop()
first,last=cases.date.min(),cases.date.max()
st.caption(f"**Mode:** {source_mode} · **Coverage:** {first:%d %b %Y} – {last:%d %b %Y} · **Clean rows:** {len(cases):,} · **Last loaded:** {pd.Timestamp.now():%d %b %Y %H:%M}")

with st.sidebar:
    st.divider(); st.header("🔎 Filters")
    states=sorted(cases.state.dropna().unique().tolist())
    chosen=st.multiselect("States / UTs",states,default=states)
    dr=st.date_input("Date range",value=(first.date(),last.date()),min_value=first.date(),max_value=last.date())
    ranking=st.selectbox("Rank states by",["confirmed","active_estimate","new_cases","cured","deaths","recovery_rate","death_rate"],format_func=lambda x:x.replace("_"," ").title())
    smooth=st.slider("Daily trend smoothing (days)",1,21,7)
if isinstance(dr,(tuple,list)) and len(dr)==2: start,end=pd.Timestamp(dr[0]),pd.Timestamp(dr[1])
else: start,end=first,last
filtered=cases[cases.state.isin(chosen)&cases.date.between(start,end)].copy()
if filtered.empty: st.warning("No data matches these filters. Select at least one state and a valid date range."); st.stop()
latest_date=filtered.date.max(); snap=filtered[filtered.date.eq(latest_date)].copy()
national=filtered.groupby("date",as_index=False)[["confirmed","cured","deaths","active_estimate","new_cases","new_deaths","new_recovered"]].sum().sort_values("date")
national["new_cases_rolling"] = national.new_cases.rolling(smooth,min_periods=1).mean()
national["recovery_rate"]=(national.cured/national.confirmed.replace(0,np.nan)*100).fillna(0)
national["death_rate"]=(national.deaths/national.confirmed.replace(0,np.nan)*100).fillna(0)
latest_snap=snap.groupby("state",as_index=False)[["confirmed","cured","deaths","active_estimate","new_cases","recovery_rate","death_rate"]].max()

# Summary strip
m1,m2,m3,m4,m5,m6=st.columns(6)
m1.metric("Confirmed",format_num(latest_snap.confirmed.sum()))
m2.metric("Recovered",format_num(latest_snap.cured.sum()))
m3.metric("Deaths",format_num(latest_snap.deaths.sum()))
m4.metric("Active estimate",format_num(latest_snap.active_estimate.sum()))
m5.metric("Recovery rate",f"{(latest_snap.cured.sum()/latest_snap.confirmed.sum()*100 if latest_snap.confirmed.sum() else 0):.1f}%")
m6.metric("States selected",str(filtered.state.nunique()))
st.caption(f"Summary is for selected states at their latest common available date in this filtered view: **{latest_date:%d %B %Y}**. Active is an estimate derived from cumulative totals.")

tabs=st.tabs(["📊 Overview","📈 Trends & peaks","🧭 State intelligence","🧪 Data quality","💉 Vaccination","📁 Explore & export","📝 Auto report"])
with tabs[0]:
    left,right=st.columns([1.7,1])
    with left:
        st.subheader("National cumulative burden")
        f=px.line(national,x="date",y=["confirmed","cured","deaths"],labels={"date":"Date","value":"People","variable":"Series"},color_discrete_map={"confirmed":"#2563eb","cured":"#0d9488","deaths":"#dc2626"})
        f.update_layout(hovermode="x unified",legend_title_text="",margin=dict(l=10,r=10,t=25,b=10)); st.plotly_chart(f,use_container_width=True)
    with right:
        st.subheader("Share of confirmed cases")
        pie=latest_snap.nlargest(6,"confirmed")[ ["state","confirmed"] ].copy()
        others=max(0,latest_snap.confirmed.sum()-pie.confirmed.sum())
        if others: pie=pd.concat([pie,pd.DataFrame([{"state":"Other selected states","confirmed":others}])],ignore_index=True)
        st.plotly_chart(px.pie(pie,names="state",values="confirmed",hole=.55),use_container_width=True)
    st.subheader("Key observations from selected data")
    if len(national)>1:
        peak=national.loc[national.new_cases.idxmax()]
        st.write(f"- Highest reported daily case count in the selected window: **{format_num(peak.new_cases)}** on **{peak.date:%d %b %Y}**.")
        st.write(f"- The latest smoothed daily count ({smooth}-day mean) is **{national.new_cases_rolling.iloc[-1]:,.1f}**.")
        st.write(f"- Selected view spans **{(national.date.max()-national.date.min()).days+1:,} calendar days** and **{filtered.state.nunique()} state/UT labels**.")
    else: st.write("Select a wider date range to reveal temporal patterns.")
with tabs[1]:
    st.subheader("Daily reported cases and smoothed trend")
    f=go.Figure(); f.add_trace(go.Bar(x=national.date,y=national.new_cases,name="Reported daily cases",marker_color="#93c5fd")); f.add_trace(go.Scatter(x=national.date,y=national.new_cases_rolling,name=f"{smooth}-day moving average",line=dict(color="#1d4ed8",width=3)))
    f.update_layout(hovermode="x unified",yaxis_title="Cases",xaxis_title="Date",legend_title_text=""); st.plotly_chart(f,use_container_width=True)
    a,b=st.columns(2)
    with a:
        st.plotly_chart(px.line(national,x="date",y=["recovery_rate","death_rate"],labels={"date":"Date","value":"Percent","variable":"Rate"},title="Recovery and reported death rates",color_discrete_map={"recovery_rate":"#0d9488","death_rate":"#dc2626"}),use_container_width=True)
    with b:
        st.plotly_chart(px.area(national,x="date",y="active_estimate",title="Estimated active cases",labels={"date":"Date","active_estimate":"Estimated active"},color_discrete_sequence=["#7c3aed"]),use_container_width=True)
    st.markdown("**How to interpret:** a moving average reduces day-to-day reporting noise; it is descriptive, not a prediction. Changes in testing/reporting can alter apparent peaks.")
with tabs[2]:
    st.subheader("State / UT comparison")
    ranked=latest_snap.sort_values(ranking,ascending=False)
    st.plotly_chart(px.bar(ranked.head(15).sort_values(ranking),x=ranking,y="state",orientation="h",color=ranking,color_continuous_scale="Blues",labels={ranking:ranking.replace("_"," ").title(),"state":"State / UT"},title=f"Top states by {ranking.replace('_',' ')}"),use_container_width=True)
    st.plotly_chart(px.scatter(latest_snap,x="recovery_rate",y="death_rate",size="confirmed",hover_name="state",color="active_estimate",title="Recovery rate vs reported death rate",labels={"recovery_rate":"Recovery rate (%)","death_rate":"Reported death rate (%)","confirmed":"Confirmed cases"}),use_container_width=True)
    st.dataframe(ranked.round(2),use_container_width=True,hide_index=True)
    if {"lat","long"}.issubset(filtered.columns):
        geo=filtered.dropna(subset=["lat","long"])
        if not geo.empty:
            geo=geo[geo.date.eq(latest_date)].drop_duplicates("state")
            st.subheader("Geographic view (only if coordinates are supplied)")
            st.map(geo.rename(columns={"lat":"latitude","long":"longitude"})[["latitude","longitude"]])
    st.download_button("Download state ranking CSV",ranked.to_csv(index=False).encode(),"state_ranking.csv","text/csv")
with tabs[3]:
    st.subheader("Data quality & cleaning audit")
    raw_q=quality_summary(raw); clean_q=quality_summary(cases)
    q1,q2,q3,q4=st.columns(4); q1.metric("Input rows",format_num(raw_q['rows'])); q2.metric("Clean rows",format_num(clean_q['rows'])); q3.metric("State labels",str(clean_q['states'])); q4.metric("Duplicate date/state rows",str(clean_q['duplicate_date_state']))
    audit=pd.DataFrame({"Check":["Input row count","Clean row count","Input columns","Clean columns","Missing cells after cleaning","Duplicate date/state pairs after cleaning","Distinct state labels","First observation","Last observation"],"Result":[raw_q['rows'],clean_q['rows'],raw_q['columns'],clean_q['columns'],clean_q['missing_cells'],clean_q['duplicate_date_state'],clean_q['states'],str(clean_q['date_min']),str(clean_q['date_max'])]})
    st.dataframe(audit,use_container_width=True,hide_index=True)
    missing=cases.isna().sum().rename("Missing values").reset_index().rename(columns={"index":"Column"})
    st.plotly_chart(px.bar(missing,x="Column",y="Missing values",title="Missing values by column"),use_container_width=True)
    st.markdown("**Cleaning performed:** required-column validation; date parsing; numeric conversion; empty date/state removal; negative cumulative values clipped to zero; duplicate state/date records consolidated; derived rates guarded against division by zero.")
    st.warning("Duplicate cumulative records are consolidated using the maximum cumulative count, while daily counts are summed. Confirm this policy matches the source's reporting semantics before making official claims.")
with tabs[4]:
    st.subheader("India vaccination progress")
    try:
        vax=fetch_csv(VAX_URL); vax["date"]=pd.to_datetime(vax["date"],errors="coerce"); vax=vax.dropna(subset=["date"]).sort_values("date")
        cols=[c for c in ["total_vaccinations","people_vaccinated","people_fully_vaccinated","total_boosters"] if c in vax]
        if not cols: st.warning("No recognized vaccination series in source schema.")
        else:
            default=[c for c in ["total_vaccinations","people_fully_vaccinated"] if c in cols]
            selected=st.multiselect("Vaccination series",cols,default=default)
            if selected: st.plotly_chart(px.line(vax,x="date",y=selected,labels={"date":"Date","value":"Count","variable":"Series"},title="Vaccination progress reported by OWID"),use_container_width=True)
            st.caption(f"Vaccination data coverage: {vax.date.min():%d %b %Y} – {vax.date.max():%d %b %Y}.")
            st.download_button("Download vaccination CSV",vax.to_csv(index=False).encode(),"india_vaccination.csv","text/csv")
    except Exception as e: st.warning(f"Vaccination source unavailable: {e}. Other dashboard sections still work.")
with tabs[5]:
    st.subheader("Explore filtered records")
    c1,c2=st.columns([2,1]); search=c1.text_input("Search state / UT"); columns=c2.multiselect("Columns to display",filtered.columns.tolist(),default=[c for c in ["date","state","confirmed","cured","deaths","active_estimate","new_cases","recovery_rate","death_rate"] if c in filtered])
    shown=filtered[filtered.state.str.contains(search,case=False,na=False)] if search else filtered
    st.caption(f"Showing {len(shown):,} records")
    st.dataframe(shown[columns] if columns else shown,use_container_width=True,hide_index=True)
    st.download_button("⬇ Download filtered CSV",shown.to_csv(index=False).encode(),"covid_india_filtered.csv","text/csv")
    st.download_button("⬇ Download complete cleaned CSV",cases.to_csv(index=False).encode(),"covid_india_cleaned.csv","text/csv")
    st.download_button("⬇ Download national daily summary",national.to_csv(index=False).encode(),"national_daily_summary.csv","text/csv")
with tabs[6]:
    st.subheader("Generate a shareable analysis report")
    st.write("Builds a portable HTML report from the current filters, with summary figures, state snapshot, methodology, and limitations. Open it in a browser or print it to PDF.")
    st.text_input("Report title",value="COVID-19 India — Exploratory Data Analysis",key="report_title")
    st.download_button("Generate & download HTML report",make_report(filtered,source_mode,ranking),"COVID19_India_EDA_Report.html","text/html",type="primary")
    st.info("For academic submission, include screenshots from a successful run, discuss at least three findings, cite the dataset version, and clearly identify whether values are observed or synthetic demo data.")

st.divider()
st.markdown("**Project pipeline:** Source / upload → validation → normalization → duplicate handling → derived indicators → filtered exploration → visualization → export/report.")
st.caption("Educational EDA only. No patient-level data is collected. This tool does not diagnose, forecast clinical outcomes, or provide medical advice.")
