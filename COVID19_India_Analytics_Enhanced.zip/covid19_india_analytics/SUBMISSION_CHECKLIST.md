# Submission Checklist for Strong Evaluation

- [ ] Create and activate a virtual environment; install `requirements.txt`.
- [ ] Run `python -m pytest -q` and keep the actual test output.
- [ ] Launch the app with `streamlit run app.py`.
- [ ] Upload or fetch a verifiable dataset; note the URL and retrieval date.
- [ ] Record the dataset's first and last observation dates.
- [ ] Take screenshots of Overview, Trends, State Intelligence, Data Quality, and Export/Report tabs.
- [ ] Replace the Results section in `PROJECT_REPORT.md` with findings from the actual data.
- [ ] Include one or two unexpected observations and explain them cautiously.
- [ ] Explain the duplicate-handling policy and derived metrics during viva.
- [ ] Never submit synthetic demo values as real epidemiological findings.
- [ ] Check citations and comply with the instructor's required report/PPT format.

## Suggested 5-minute demonstration
1. State the problem and show the pipeline (30 seconds).
2. Show date/state filters and national trend chart (60 seconds).
3. Compare states and explain the reported death rate vs. infection fatality rate (60 seconds).
4. Show the data-quality audit and explain duplicate handling (60 seconds).
5. Export the cleaned CSV and generate the HTML report (45 seconds).
6. Explain data freshness, limitations, and future work (45 seconds).

## Future work (only claim completed items if actually implemented)
- Add official maintained health-authority data feeds if available.
- Add automated schema-drift alerts and source checksums.
- Add epidemiologically reviewed nowcasting only with suitable data and validation.
- Add role-based deployments and scheduled ingestion for a hosted production version.
