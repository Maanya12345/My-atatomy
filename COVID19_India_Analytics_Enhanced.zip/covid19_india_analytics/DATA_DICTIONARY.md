# Data Dictionary

| Field | Meaning | Notes |
|---|---|---|
| `date` | Observation date | Parsed to datetime; invalid dates removed |
| `state` | State/UT label | Trimmed; source spelling differences may remain |
| `confirmed` | Cumulative confirmed cases | Numeric; missing values filled with 0 after validation |
| `cured` | Cumulative recovered/discharged | Source terminology varies; treated as cumulative recovered |
| `deaths` | Cumulative reported deaths | Not equivalent to infection fatality rate |
| `new_cases` | Daily reported cases | Uses source column when available; otherwise inferred from cumulative differences |
| `new_deaths` | Daily reported deaths | Uses source column or inferred differences when absent |
| `new_recovered` | Daily reported recoveries | Uses source column or inferred differences when absent |
| `active_estimate` | Confirmed minus cured minus deaths | Clipped at zero; an estimate, not a clinical status measure |
| `recovery_rate` | Cured / confirmed × 100 | Set to zero when confirmed is zero; clipped to 0–100 |
| `death_rate` | Deaths / confirmed × 100 | Reported death rate; not infection fatality rate |
| `lat`, `long` | Optional coordinates | Geographic view only appears when coordinates are supplied |

## Duplicate policy
Rows with the same date and state/UT are consolidated. Cumulative totals use the maximum to avoid double-counting duplicated cumulative snapshots; available daily counts are summed. Review source semantics before interpreting daily totals if duplicates reflect genuine revisions rather than duplicate records.
