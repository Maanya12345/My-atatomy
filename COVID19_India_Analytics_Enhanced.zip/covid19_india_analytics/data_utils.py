"""Reusable ingestion, validation and feature engineering for COVID-19 India EDA."""
from __future__ import annotations
import pandas as pd

ALIASES = {
    "Date":"date", "Name of State / UT":"state", "State":"state", "state/ut":"state",
    "Latitude":"lat", "Longitude":"long", "Total Confirmed cases":"confirmed",
    "Confirmed":"confirmed", "confirmed_cases":"confirmed", "Death":"deaths", "Deaths":"deaths",
    "Cured/Discharged/Migrated":"cured", "Cured":"cured", "recovered":"cured",
    "New cases":"new_cases", "New deaths":"new_deaths", "New recovered":"new_recovered",
}
REQUIRED = {"date", "state", "confirmed", "deaths", "cured"}

def normalise_cases(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize supported public-source column names and collapse date/state duplicates."""
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise ValueError("The input dataset is empty. Upload a CSV containing COVID-19 observations.")
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    rename = {}
    for c in out.columns:
        key = c.strip()
        rename[c] = ALIASES.get(key, ALIASES.get(key.lower(), key.lower().replace(" ", "_")))
    out = out.rename(columns=rename)
    # Handle case-insensitive canonical names.
    out = out.rename(columns={c: c.lower() for c in out.columns})
    missing = REQUIRED - set(out.columns)
    if missing:
        raise ValueError("CSV is missing required columns: " + ", ".join(sorted(missing)))
    out["date"] = pd.to_datetime(out["date"], errors="coerce", dayfirst=True)
    out["state"] = out["state"].astype("string").str.strip()
    numeric = ["confirmed", "deaths", "cured", "new_cases", "new_deaths", "new_recovered", "lat", "long"]
    for c in numeric:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c].astype(str).str.replace(",", "", regex=False).str.replace("%", "", regex=False), errors="coerce")
    out = out.dropna(subset=["date", "state"])
    out = out[out["state"].str.len().fillna(0) > 0]
    for c in ["confirmed", "deaths", "cured"]:
        out[c] = out[c].fillna(0).clip(lower=0)
    agg = {c: "max" for c in ["confirmed", "deaths", "cured"]}
    for c in ["new_cases", "new_deaths", "new_recovered"]:
        if c in out.columns: agg[c] = "sum"
    for c in ["lat", "long"]:
        if c in out.columns: agg[c] = "first"
    result = out.groupby(["date", "state"], as_index=False).agg(agg)
    return result.sort_values(["date", "state"]).reset_index(drop=True)

def add_derived(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy().sort_values(["state", "date"]).reset_index(drop=True)
    denom = d["confirmed"].where(d["confirmed"] != 0)
    d["recovery_rate"] = (d["cured"] / denom * 100).fillna(0).clip(0, 100)
    d["death_rate"] = (d["deaths"] / denom * 100).fillna(0).clip(0, 100)
    d["active_estimate"] = (d["confirmed"] - d["cured"] - d["deaths"]).clip(lower=0)
    if "new_cases" not in d.columns:
        d["new_cases"] = d.groupby("state")["confirmed"].diff().fillna(d["confirmed"]).clip(lower=0)
    else:
        # Prefer source values, but infer missing daily values from cumulative changes.
        inferred = d.groupby("state")["confirmed"].diff().fillna(d["confirmed"]).clip(lower=0)
        d["new_cases"] = d["new_cases"].where(d["new_cases"].notna(), inferred).fillna(0).clip(lower=0)
    if "new_deaths" not in d.columns:
        d["new_deaths"] = d.groupby("state")["deaths"].diff().fillna(d["deaths"]).clip(lower=0)
    if "new_recovered" not in d.columns:
        d["new_recovered"] = d.groupby("state")["cured"].diff().fillna(d["cured"]).clip(lower=0)
    return d.sort_values(["date", "state"]).reset_index(drop=True)

def quality_summary(df: pd.DataFrame) -> dict:
    """Summarize quality issues without silently modifying source data further."""
    return {
        "rows": int(len(df)), "columns": int(len(df.columns)),
        "duplicate_date_state": int(df.duplicated(["date", "state"]).sum()) if {"date", "state"}.issubset(df.columns) else None,
        "missing_cells": int(df.isna().sum().sum()),
        "states": int(df["state"].nunique()) if "state" in df else 0,
        "date_min": df["date"].min() if "date" in df and len(df) else None,
        "date_max": df["date"].max() if "date" in df and len(df) else None,
    }
