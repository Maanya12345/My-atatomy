import pandas as pd
import pytest
from data_utils import normalise_cases, add_derived, quality_summary

def test_original_source_columns_normalise_and_duplicates_collapse():
    raw=pd.DataFrame({"Date":["2020-01-01","2020-01-01","2020-01-02"],"Name of State / UT":["Example","Example","Example"],"Total Confirmed cases":["10","10","15"],"Death":["1","1","2"],"Cured/Discharged/Migrated":["4","4","8"],"New cases":["3","2","5"]})
    out=normalise_cases(raw)
    assert len(out)==2 and out.iloc[0].confirmed==10 and out.iloc[0].new_cases==5

def test_rates_active_and_zero_denominator():
    df=pd.DataFrame({"date":pd.to_datetime(["2020-01-01","2020-01-02"]),"state":["A","B"],"confirmed":[10,0],"deaths":[1,0],"cured":[5,0]})
    out=add_derived(df)
    assert out.loc[0,"recovery_rate"]==50 and out.loc[0,"death_rate"]==10 and out.loc[0,"active_estimate"]==4
    assert out.loc[1,"recovery_rate"]==0 and out.loc[1,"death_rate"]==0

def test_missing_required_column_has_actionable_error():
    with pytest.raises(ValueError,match="missing required columns"):
        normalise_cases(pd.DataFrame({"date":["2020-01-01"],"state":["A"]}))

def test_empty_input_rejected():
    with pytest.raises(ValueError,match="empty"):
        normalise_cases(pd.DataFrame())

def test_negative_values_clipped_and_dates_invalid_removed():
    raw=pd.DataFrame({"date":["bad","2020-01-01"],"state":["A","A"],"confirmed":[3,-2],"deaths":[0,-1],"cured":[1,-3]})
    out=normalise_cases(raw)
    assert len(out)==1 and out.iloc[0].confirmed==0 and out.iloc[0].deaths==0 and out.iloc[0].cured==0

def test_quality_summary_counts_duplicates():
    df=pd.DataFrame({"date":pd.to_datetime(["2020-01-01"]),"state":["A"],"x":[None]})
    q=quality_summary(df)
    assert q["rows"]==1 and q["missing_cells"]==1 and q["duplicate_date_state"]==0
