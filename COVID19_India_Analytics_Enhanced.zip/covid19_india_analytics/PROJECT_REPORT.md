# COVID-19 India Insight Studio — Mini Project Report

## Abstract
This project develops an interactive exploratory data analysis workflow for historical COVID-19 observations in India. It combines CSV ingestion, data normalization, validation, feature engineering, visual exploration, data export, and report generation in one reproducible application. A clear source-freshness warning prevents a refresh operation from being mistaken for live epidemiological surveillance.

## Problem statement
Public health datasets may be large, inconsistent, and difficult to compare across dates and state/UT labels. Manual analysis can conceal missing values, duplicates, reporting differences, and trends.

## Objectives
1. Load historical data from a public CSV source or a compatible user-provided file.
2. Standardize dates, numeric values, and column names.
3. Handle duplicate date/state records and invalid rows transparently.
4. Calculate recovery rate, reported death rate, estimated active cases, and daily changes.
5. Visualize national time series and state-level differences.
6. Provide data-quality diagnostics and downloadable outputs.

## System design
**Ingestion → validation → normalization → duplicate consolidation → derived indicators → filtering → visualization → export/report.**

## Technology stack
Python, Pandas, NumPy, Streamlit, Plotly, Requests, and Pytest.

## Core calculations
- Estimated active cases = confirmed − recovered − deaths, with negative results clipped to zero.
- Recovery rate (%) = recovered / confirmed × 100, with zero-denominator protection.
- Reported death rate (%) = deaths / confirmed × 100, with zero-denominator protection.
- Smoothed daily cases = rolling mean over the selected number of days.

These measures depend on source definitions and are descriptive. The reported death rate is not a clinical infection fatality rate.

## Results and discussion template
Run the app against the selected verified dataset and record the observation window, number of states/UTs, peak reported daily count and date, highest cumulative-burden states, and notable data-quality issues. Insert screenshots of the live application here. Do not fill this section with invented values; record results from the actual dataset used.

## Testing
The included unit tests check source-column normalization, duplicate consolidation, missing required columns, empty input, negative values, invalid dates, derived rates, and data-quality summaries. Run `python -m pytest -q` and include the actual test output in the final submission.

## Limitations
Data sources may be historical, revised, incomplete, or unavailable. Active cases are estimated from cumulative totals. Associations in charts do not imply causation. Synthetic demo data exists only to demonstrate the user interface and must not be used as research evidence.

## Conclusion
The application turns a notebook-oriented EDA exercise into a reusable interactive analysis workflow with transparent data-quality handling and exportable results. The quality of any conclusion still depends on verifying the source, recording its coverage dates, and interpreting the indicators cautiously.

## References
1. India historical COVID-19 dataset repository: https://github.com/imdevskp/covid-19-india-data
2. Our World in Data vaccination dataset: https://github.com/owid/covid-19-data/tree/master/public/data/vaccinations/country_data
3. Streamlit documentation: https://docs.streamlit.io/
4. Plotly Python documentation: https://plotly.com/python/
